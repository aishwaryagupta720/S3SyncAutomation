**To delete a method for the given resource in an API**

Command::

  aws apigateway delete-method --rest-api-id 1234123412 --resource-id a1b2c3 --http-method GET
